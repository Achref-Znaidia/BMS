# BMS - Business Management System
# Main package initialization
